# -*- coding: utf-8 -*-
"""
Created on Sun Oct 21 18:19:48 2018

@author: Margarida Costa
"""

# -*- coding: utf-8 -*-
"""

"""
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import pandas as pd
# loading libraries
import numpy as np
from sklearn.cross_validation import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
import preprocessing as pp

#from util.dummy_var import ProcessData

print( '-----------------------------------' )

data = {#pd.read_csv( f'{DATA_PATH}/{data_file}' )
    'test': pd.read_csv( r'.\data\Truck\aps_failure_test_set.csv' ),
    'train': pd.read_csv( r'.\data\Truck\aps_failure_training_set.csv' ),
}

print( '>>> Loaded truck\'s data!' )

#print( [*data] )
pp.treatSymbolicAtt(data['test'])
pp.treatSymbolicAtt(data['train'])
pp.treatSymbolicBinaryAtts(data['test'], "class", "pos")
pp.treatSymbolicBinaryAtts(data['train'], "class", "pos")
pp.treatMissingValues(data['test'], "meanByClass")

X_test  = data['test'].drop( 'class', axis=1 ).values
y_test  = data['test'][ 'class' ].values
X_train, y_train =  pp.treatUnbalancedData(data, "SMOTE")


# creating odd list of K for KNN
myList = list(range(1,20))

# subsetting just the odd ones
neighbors = list(filter(lambda x: x % 2 != 0, myList))

# empty list that will hold cv scores
cv_scores = []

# perform 10-fold cross validation
for k in neighbors:
    knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(knn, X_train, y_train, cv=10, scoring='accuracy')
    cv_scores.append(scores.mean())
    # fitting the model
    knnModel = knn.fit(X_train, y_train)
    # predict the response
    y_pred = knnModel.predict(X_test)
    print("accuracy knn", accuracy_score(y_test, y_pred))
    cm = confusion_matrix(y_test, y_pred, labels=pd.unique(y_train))
    print("confusion matrix", cm)
    print("TPrate knn ",cm[0][0]/(cm[0][0]+cm[1][0]))
    print("specificity knn", cm[1][1]/(cm[1][1]+cm[0][1]))
        


